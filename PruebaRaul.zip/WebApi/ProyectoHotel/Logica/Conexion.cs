﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoHotel.Logica
{
    public class Conexion
    {
        public static string CN = "Data Source=.;Initial Catalog=DB_HOTEL;Integrated Security=True";
    }
}