﻿using ProyectoHotel.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;

namespace ProyectoHotel.Logica
{
    public class HotelLogica
    {
        private static HotelLogica instancia = null;

        public HotelLogica()
        {

        }

        public static HotelLogica Instancia
        {
            get
            {
                if (instancia == null)
                {
                    instancia = new HotelLogica();
                }

                return instancia;
            }
        }

        public bool Registrar(Hotel oHabitacion)
        {
            bool respuesta = true;
            using (SqlConnection oConexion = new SqlConnection(Conexion.CN))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("sp_RegistrarHotel", oConexion);
                    //cmd.Parameters.AddWithValue("Id", 0);
                    cmd.Parameters.AddWithValue("Nombre", oHabitacion.Nombre);
                    cmd.Parameters.AddWithValue("Estado", oHabitacion.Estado);
                   
                    //cmd.Parameters.Add("Resultado", SqlDbType.Bit).Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;

                    oConexion.Open();

                    cmd.ExecuteNonQuery();

                    respuesta = Convert.ToBoolean(cmd.Parameters["Estado"].Value);

                }
                catch (Exception ex)
                {
                    respuesta = false;
                }
            }
            return respuesta;
        }

        public bool Modificar(Hotel oHabitacion)
        {
            bool respuesta = true;
            using (SqlConnection oConexion = new SqlConnection(Conexion.CN))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("sp_ModificarHabitacion", oConexion);
                    cmd.Parameters.AddWithValue("Id", 0);
                    cmd.Parameters.AddWithValue("Nombre", oHabitacion.Nombre);
                    cmd.Parameters.AddWithValue("Estado", oHabitacion.Estado);
                    cmd.Parameters.Add("Resultado", SqlDbType.Bit).Direction = ParameterDirection.Output;

                    cmd.CommandType = CommandType.StoredProcedure;

                    oConexion.Open();

                    cmd.ExecuteNonQuery();

                    respuesta = Convert.ToBoolean(cmd.Parameters["Resultado"].Value);

                }
                catch (Exception ex)
                {
                    respuesta = false;
                }

            }

            return respuesta;

        }


        public bool ModificarHotel(Hotel oHabitacion)
        {
            bool respuesta = true;
            using (SqlConnection oConexion = new SqlConnection(Conexion.CN))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("sp_ActualizarHotel", oConexion);
                    cmd.Parameters.AddWithValue("Id", oHabitacion.IdHotel);
                    cmd.Parameters.AddWithValue("Nombre", oHabitacion.Nombre);
                    cmd.Parameters.AddWithValue("Estado", oHabitacion.Estado);
                    cmd.Parameters.Add("Resultado", SqlDbType.Bit).Direction = ParameterDirection.Output;

                    cmd.CommandType = CommandType.StoredProcedure;

                    oConexion.Open();

                    cmd.ExecuteNonQuery();

                    respuesta = Convert.ToBoolean(cmd.Parameters["Resultado"].Value);

                }
                catch (Exception ex)
                {
                    respuesta = false;
                }

            }

            return respuesta;

        }

        public List<Hotel> ListarHotelHabitacion()
        {
            List<Hotel> Lista = new List<Hotel>();
            using (SqlConnection oConexion = new SqlConnection(Conexion.CN))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("select IdHotel,Nombre from Hotel", oConexion);
                    cmd.CommandType = CommandType.Text;

                    oConexion.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Lista.Add(new Hotel()
                            {
                                IdHotel = Convert.ToInt32(dr["IdHotel"]),
                                Nombre = dr["Nombre"].ToString()
                                //Estado = Convert.ToBoolean(dr["Estado"])
                            });
                        }
                    }

                }
                catch (Exception ex)
                {
                    Lista = new List<Hotel>();
                }
            }
            return Lista;
        }

        public List<Hotel> Listar()
        {
            List<Hotel> Lista = new List<Hotel>();
            using (SqlConnection oConexion = new SqlConnection(Conexion.CN))
            {
                try
                {
                    StringBuilder query = new StringBuilder();
                    //query.AppendLine("select h.IdHabitacion,h.Numero,h.Detalle,h.Precio,p.IdPiso,p.Descripcion[DescripcionPiso],c.IdCategoria,c.Descripcion[DescripcionCategoria],h.Estado,");
                    query.AppendLine("select h.IdHotel,h.Nombre,h.Estado,h.FechaCreacion");
                    //query.AppendLine("eh.IdEstadoHabitacion,eh.Descripcion[DescripcionEstadoHabitacion]");
                    query.AppendLine("from hotel h");
                    //query.AppendLine("inner join PISO p on p.IdPiso = h.IdPiso");
                    //query.AppendLine("inner join CATEGORIA c on c.IdCategoria = h.IdCategoria");
                    //query.AppendLine("inner join ESTADO_HABITACION eh on eh.IdEstadoHabitacion = h.IdEstadoHabitacion");

                    SqlCommand cmd = new SqlCommand(query.ToString(), oConexion);
                    cmd.CommandType = CommandType.Text;

                    oConexion.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Lista.Add(new Hotel()
                            {
                                IdHotel = Convert.ToInt32(dr["IdHotel"]),
                                Nombre = dr["Nombre"].ToString(),
                                Estado = Convert.ToBoolean(dr["Estado"]),
                                FechaCreacion =  Convert.ToString( dr["FechaCreacion"]),
                            });
                        }
                    }

                }
                catch (Exception ex)
                {
                    Lista = new List<Hotel>();
                }
            }
            return Lista;
        }

        public bool Eliminar(int IdHotel)
        {
            bool respuesta = true;
            using (SqlConnection oConexion = new SqlConnection(Conexion.CN))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("delete from Hotel where IdHotel = @IdHotel", oConexion);
                    cmd.Parameters.AddWithValue("@IdHotel", IdHotel);
                    cmd.CommandType = CommandType.Text;

                    oConexion.Open();

                    cmd.ExecuteNonQuery();

                    respuesta = true;

                }
                catch (Exception ex)
                {
                    respuesta = false;
                }

            }

            return respuesta;

        }

        public bool ActualizarEstado(int idhabitacion, int idestadohabitacion)
        {
            bool respuesta = true;
            using (SqlConnection oConexion = new SqlConnection(Conexion.CN))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("update HABITACION set idestadohabitacion = @idestadohabitacion where IdHabitacion = @idhabitacion ", oConexion);
                    cmd.Parameters.AddWithValue("@idhabitacion", idhabitacion);
                    cmd.Parameters.AddWithValue("@idestadohabitacion", idestadohabitacion);
                    cmd.CommandType = CommandType.Text;

                    oConexion.Open();

                    cmd.ExecuteNonQuery();

                    respuesta = true;

                }
                catch (Exception ex)
                {
                    respuesta = false;
                }

            }

            return respuesta;

        }
    }
}