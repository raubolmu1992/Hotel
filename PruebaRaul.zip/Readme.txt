

1. Importar la base de datos desde el archivo llamado: "BdCompleta" para obetner las tablas, registros y procedimentos almacenados 
o ejecutar los script "Script crea bd y tablas,Script Procedimientos Almacenados,Script Insertar Datos"  los cuales se encuentra en la carpeta: "Scripts"
2. Abrir el proyecto y ejecutar la solucion Proyecto.sln,  la cual se encuentra en la carpeta: "WebApi" 
3. De igual manera se relaciona la documentación realizada de las funciones del proyecto mediante el archivo llamaado: "PRUEBA TÉCNICA PARA DESARROLLADOR BACK END"
6. Para obtener el proyecto los descargamos desde OneDrive: https://1drv.ms/u/s!AoUk4Iz8YBBf8FvTD2ZhS3GFooOm?e=lry4jt


Muchas Gracias
Cordialmente

Raúl Eduardo Bolaños Muñoz
Cali Valle
Celular: 3113962704
Correo: rauleduardo1992@hotmail.com

Saludos y Bendiciones.

